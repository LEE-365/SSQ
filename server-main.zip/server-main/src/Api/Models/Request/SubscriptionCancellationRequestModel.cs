﻿namespace Bit.Api.Models.Request;

public class SubscriptionCancellationRequestModel
{
    public string Reason { get; set; }
    public string Feedback { get; set; }
}
